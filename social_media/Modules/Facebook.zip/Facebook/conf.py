#database details
dbname="Facebook"
host="localhost"
port="5432"
user= "postgres"
password= "ticker@1234"