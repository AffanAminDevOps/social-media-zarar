from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium.webdriver.common.keys import Keys
try:
    import undetected_chromedriver as webdriver
    from webdriver_manager.firefox import GeckoDriverManager

    # Assuming undetected_chromedriver is compatible with Firefox as well
except:
    from selenium import webdriver

import os
from pathlib import Path
from database import *
import requests
import datetime
import time
import random


import os
from pathlib import Path
from database import *
import requests
import datetime
import time
import random

def scroll_post(driver, posts=1, special=False):
    for i in range(posts):
        # Define the scroll step size and total steps
        scroll_step = 10  # Adjust the step size as needed
        total_steps = 77  # Adjust the total number of steps as needed
        
        # Perform slow scroll down the page
        for step in range(total_steps):
            driver.execute_script(f"window.scrollBy(0, {scroll_step});")
            driver.implicitly_wait(0.1)  # Wait to create a smooth scroll effect
        if special:
            time.sleep(3)

def sleep_random_time():
    # Generate a random sleep time between 45 and 60 minutes
    sleep_time = random.randint(45 * 60, 60 * 60)  # Convert minutes to seconds
    print("Stoped for ", sleep_time//60)
        # Sleep for the random time
    time.sleep(sleep_time)

def is_between_1am_and_3am(current_time):
    return current_time.time() >= datetime.time(1, 0) and current_time.time() <= datetime.time(3, 0)


def download_image(image_url):

    # Send an HTTP GET request to the image URL
    response = requests.get(image_url)
    current_time = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    # Check if the request was successful (status code 200)
    if response.status_code == 200:
        # Get the content of the response (image bytes)
        image_content = response.content
        file_extension = "png"
        # Specify the path where you want to save the image
        save_path = f"{current_time}.{file_extension}"
        
        # Save the image content to the specified path
        with open(save_path, 'wb') as f:
            f.write(image_content)
        return save_path
    else:
        print("Failed to download the image.")
        return None


def open_profile(profile="-", new=False, headless=False):
    if profile == "-":
        new=True
    if new:
        if headless:
            firefox_options = FirefoxOptions()
            firefox_options.add_argument('--headless')
            browser = webdriver.Firefox(executable_path=GeckoDriverManager().install(), options=firefox_options)
        else:
            browser = webdriver.Firefox(executable_path=GeckoDriverManager().install())
    
    else:
        current_directory = os.getcwd()
        print("Opening Profile:", current_directory , fr"\{profile}")
        user_data_dir = Path(rf"{current_directory}\{profile}")
        firefox_options = webdriver.FirefoxOptions()
        
        if headless:
            firefox_options.add_argument('--headless')
        
        firefox_options.add_argument("--profile={}".format(user_data_dir))
        browser = webdriver.Firefox(executable_path=GeckoDriverManager().install(), options=firefox_options)
    
    if not headless:
        width = 1080  
        height = 740 
        browser.set_window_size(width, height)
    
    return browser